#ifndef GO_LIBEDIT_NO_BUILD
#include "unvis.c"
#endif
