#ifndef GO_LIBEDIT_NO_BUILD
#include "emacs.c"
#endif
