#ifndef GO_LIBEDIT_NO_BUILD
#include "read.c"
#endif
