#ifndef GO_LIBEDIT_NO_BUILD
#include "chared.c"
#endif
