#ifndef GO_LIBEDIT_NO_BUILD
#include "strlcpy.c"
#endif
