#ifndef GO_LIBEDIT_NO_BUILD
#include "refresh.c"
#endif
