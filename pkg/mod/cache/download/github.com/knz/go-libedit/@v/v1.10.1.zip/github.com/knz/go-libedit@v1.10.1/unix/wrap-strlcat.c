#include "libedit-strlcat.c"
