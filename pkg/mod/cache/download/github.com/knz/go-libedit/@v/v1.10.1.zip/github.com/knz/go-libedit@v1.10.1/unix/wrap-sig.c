#include "libedit-sig.c"
