#ifndef GO_LIBEDIT_NO_BUILD
#include "terminal.c"
#endif
