#include "libedit-filecomplete.c"
