#ifndef GO_LIBEDIT_NO_BUILD
#include "search.c"
#endif
