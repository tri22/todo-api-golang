#ifndef GO_LIBEDIT_NO_BUILD
#include "chartype.c"
#endif
