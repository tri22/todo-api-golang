#ifndef GO_LIBEDIT_NO_BUILD
#include "prompt.c"
#endif
