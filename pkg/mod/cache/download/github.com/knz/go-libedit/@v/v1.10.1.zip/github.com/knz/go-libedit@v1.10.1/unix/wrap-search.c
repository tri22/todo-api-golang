#include "libedit-search.c"
