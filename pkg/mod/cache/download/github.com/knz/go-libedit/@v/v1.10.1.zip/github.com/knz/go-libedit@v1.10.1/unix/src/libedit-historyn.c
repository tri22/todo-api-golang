#ifndef GO_LIBEDIT_NO_BUILD
#include "historyn.c"
#endif
