#ifndef GO_LIBEDIT_NO_BUILD
#include "filecomplete.c"
#endif
