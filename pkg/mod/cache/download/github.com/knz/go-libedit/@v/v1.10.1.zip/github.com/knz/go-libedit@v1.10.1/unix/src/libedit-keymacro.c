#ifndef GO_LIBEDIT_NO_BUILD
#include "keymacro.c"
#endif
